export const CommandTimeout = 5000;
