export interface Change<T> {
  previousValue: T;
  currentValue: T;
}
